﻿namespace JournalsApi.Domain
{
    public class Issue
    {
        public int Id { get; set; }

        public int Number { get; set; }

        public string Title { get; set; }

        public string Filename { get; set; }
    }
}
