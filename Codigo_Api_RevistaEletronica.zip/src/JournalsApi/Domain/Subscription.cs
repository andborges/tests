﻿namespace JournalsApi.Domain
{
    public class Subscription
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public int JournalId { get; set; }
    }
}
