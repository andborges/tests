﻿using System.Collections.Generic;

namespace JournalsApi.Domain
{
    public class Journal
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public IList<int> Issues { get; set; }
    }
}
