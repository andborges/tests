﻿namespace JournalsApi.Controllers.V1.Contracts
{
    public class TokenPostContractInput
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
