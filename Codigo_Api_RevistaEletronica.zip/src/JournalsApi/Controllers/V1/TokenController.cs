﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using Microsoft.IdentityModel.Tokens;
using System;
using JournalsApi.Domain;
using System.IdentityModel.Tokens.Jwt;
using JournalsApi.Services.Interfaces;
using JournalsApi.Controllers.V1.Contracts;

namespace JournalsApi.Controllers.V1
{
    [Route("api/v1/[controller]")]
    public class TokenController : BaseController
    {
        private readonly TokenAuthOptions _tokenAuthOptions;
        private readonly IUserService _userService;

        public TokenController(TokenAuthOptions tokenAuthOptions, IUserService userService)
        {
            _tokenAuthOptions = tokenAuthOptions;
            _userService = userService;
        }

        // POST api/v1/token
        [AllowAnonymous]
        [HttpPost]
        public IActionResult Post([FromBody]TokenPostContractInput tokenPostContractInput)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = _userService.GetUserByUsername(tokenPostContractInput.Username);

            if (user == null || user.Password != tokenPostContractInput.Password)
            {
                return StatusCode(401);
            }

            var identity = CreateIdentity(user.Id.ToString(), user.Username, user.Name);
            var securityTokenDescriptor = CreateTokenDescriptor(identity);
            var token = CreateToken(securityTokenDescriptor);

            return Ok(new
            {
                Token = token,
                Name = user.Name,
                Username = user.Username
            });
        }

        // GET api/v1/token/test
        [HttpGet("test")]
        public IActionResult Test()
        {
            return Ok();
        }

        private static ClaimsIdentity CreateIdentity(string userid, string username, string name)
        {
            var claims = new List<Claim>
            {
                new Claim("Id", userid, ClaimValueTypes.String),
                new Claim("Username", username, ClaimValueTypes.String),
                new Claim("Name", name, ClaimValueTypes.String)
            };

            return new ClaimsIdentity(new GenericIdentity(username, "TokenAuth"), claims);
        }

        private SecurityTokenDescriptor CreateTokenDescriptor(ClaimsIdentity identity)
        {
            var now = DateTime.UtcNow;

            return new SecurityTokenDescriptor
            {
                Issuer = _tokenAuthOptions.Issuer,
                Audience = _tokenAuthOptions.Audience,
                SigningCredentials = _tokenAuthOptions.SigningCredentials,
                Subject = identity,
                IssuedAt = now,
                NotBefore = now,
                Expires = now.AddSeconds(_tokenAuthOptions.ExpirationInSeconds)
            };
        }

        private static string CreateToken(SecurityTokenDescriptor securityTokenDescriptor)
        {
            var handler = new JwtSecurityTokenHandler();
            var token = handler.CreateToken(securityTokenDescriptor);

            return handler.WriteToken(token);
        }
    }
}