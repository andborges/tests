﻿using Microsoft.AspNetCore.Mvc;
using JournalsApi.Services.Interfaces;
using System.Linq;

namespace JournalsApi.Controllers.V1
{
    [Route("api/v1/[controller]")]
    public class SubscriptionController : BaseController
    {
        private readonly ISubscriptionService _subscriptionService;
        private readonly IJournalService _journalService;

        public SubscriptionController(ISubscriptionService subscriptionService, IJournalService journalService)
        {
            _subscriptionService = subscriptionService;
            _journalService = journalService;
        }

        // POST api/v1/subscription/list
        [HttpGet("list")]
        public IActionResult List()
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var userId = CurrentUserId();
            var subscriptions = _subscriptionService.GetSubscriptionsByUserId(userId.GetValueOrDefault());
            var subscriptionsJournals = _journalService.GetJournalsById(subscriptions.Select(s => s.JournalId).ToList());

            return Ok(subscriptionsJournals.Select(j => new {
                JournalId = j.Id,
                JournalName = j.Name
            }));
        }
    }
}