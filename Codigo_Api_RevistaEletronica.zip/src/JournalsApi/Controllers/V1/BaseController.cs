﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace JournalsApi.Controllers.V1
{
    public class BaseController : Controller
    {
        protected int? CurrentUserId()
        {
            if (Request.HttpContext.User != null && Request.HttpContext.User.Claims.Any(c => c.Type == "Id"))
            {
                return int.Parse(Request.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id").Value);
            }

            return null;
        }
    }
}
