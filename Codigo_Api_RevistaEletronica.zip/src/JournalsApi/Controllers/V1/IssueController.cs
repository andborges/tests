﻿using Microsoft.AspNetCore.Mvc;
using JournalsApi.Services.Interfaces;
using System.Linq;

namespace JournalsApi.Controllers.V1
{
    [Route("api/v1/[controller]")]
    public class IssueController : BaseController
    {
        private readonly ISubscriptionService _subscriptionService;
        private readonly IJournalService _journalService;

        public IssueController(ISubscriptionService subscriptionService, IJournalService journalService)
        {
            _subscriptionService = subscriptionService;
            _journalService = journalService;
        }

        // POST api/v1/read/{id}
        [HttpGet("{id}")]
        public IActionResult Get([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var userId = CurrentUserId();
            var subscriptions = _subscriptionService.GetSubscriptionsByUserId(userId.GetValueOrDefault());
            var journal = _journalService.GetJournalByIssueId(id);

            if (!subscriptions.Any(s => s.JournalId == journal.Id))
            {
                return StatusCode(403);
            }

            var issue = _journalService.GetIssueById(id);

            var filepath = $"Issues/{issue.Filename}";
            byte[] fileBytes = System.IO.File.ReadAllBytes(filepath);

            return File(fileBytes, "application/x-msdownload", issue.Filename);
        }
    }
}