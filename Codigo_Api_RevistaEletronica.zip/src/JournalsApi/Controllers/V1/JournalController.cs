﻿using Microsoft.AspNetCore.Mvc;
using JournalsApi.Services.Interfaces;
using System.Linq;

namespace JournalsApi.Controllers.V1
{
    [Route("api/v1/[controller]")]
    public class JournalController : BaseController
    {
        private readonly ISubscriptionService _subscriptionService;
        private readonly IJournalService _journalService;

        public JournalController(ISubscriptionService subscriptionService, IJournalService journalService)
        {
            _subscriptionService = subscriptionService;
            _journalService = journalService;
        }

        // POST api/v1/journal/{id}
        [HttpGet("{id}")]
        public IActionResult Get([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var userId = CurrentUserId();
            var subscriptions = _subscriptionService.GetSubscriptionsByUserId(userId.GetValueOrDefault());

            if (!subscriptions.Any(s => s.JournalId == id))
            {
                return StatusCode(403);
            }

            var journal = _journalService.GetJournalById(id);
            var issues = _journalService.GetIssuesById(journal.Issues);

            return Ok(new {
                Name = journal.Name,
                Issues = issues.Select(e => new { e.Id, e.Title, e.Number }).ToList()
            });
        }
    }
}