﻿using JournalsApi.Domain;
using JournalsApi.Services.Interfaces;
using System.Linq;

namespace JournalsApi.Services
{
    public class UserService : IUserService
    {
        public User GetUserByUsername(string username)
        {
            return FakeData.Users.FirstOrDefault(u => u.Username == username);
        }
    }
}
