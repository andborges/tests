﻿using JournalsApi.Services.Interfaces;
using System.Collections.Generic;
using System.Linq;
using JournalsApi.Domain;

namespace JournalsApi.Services
{
    public class SubscriptionService : ISubscriptionService
    {
        public IList<Subscription> GetSubscriptionsByUserId(int userId)
        {
            return FakeData.Subscriptions.Where(s => s.UserId == userId).ToList();
        }
    }
}
