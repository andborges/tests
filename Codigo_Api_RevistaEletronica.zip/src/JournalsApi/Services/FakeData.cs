﻿using JournalsApi.Domain;
using System.Collections.Generic;

namespace JournalsApi.Services
{
    public static class FakeData
    {
        public static IList<User> Users = new List<User>
        {
            new User { Id = 1, Name = "John Bauer", Username = "jbauer", Password = "1q2w3e4r" },
            new User { Id = 2, Name = "Al Simon", Username = "asimon", Password = "1q2w3e4r" },
            new User { Id = 3, Name = "Bill Jones", Username = "bjones", Password = "1q2w3e4r" },
            new User { Id = 4, Name = "Aldo Smith", Username = "asmith", Password = "1q2w3e4r" }
        };

        public static IList<Journal> Journals = new List<Journal>
        {
            new Journal { Id = 1, Name = "Journal of Medicine", Issues = new List<int> { 1, 2, 3, 4, 5 } },
            new Journal { Id = 2, Name = "Journal of Technology", Issues = new List<int> { 6, 7, 8, 9, 10 } },
            new Journal { Id = 3, Name = "Journal of Sports", Issues = new List<int> { 11, 12, 13, 14, 15 } },
            new Journal { Id = 4, Name = "Journal of Architecture", Issues = new List<int> { 16, 17, 18, 19, 20 } }
        };

        public static IList<Issue> Issues = new List<Issue>
        {
            new Issue { Id = 1, Title = "Journal of Medicine - Issue 1", Number = 1, Filename = "Journal_Medicine_01.pdf" },
            new Issue { Id = 2, Title = "Journal of Medicine - Issue 2", Number = 2, Filename = "Journal_Medicine_02.pdf" },
            new Issue { Id = 3, Title = "Journal of Medicine - Issue 3", Number = 3, Filename = "Journal_Medicine_03.pdf" },
            new Issue { Id = 4, Title = "Journal of Medicine - Issue 4", Number = 4, Filename = "Journal_Medicine_04.pdf" },
            new Issue { Id = 5, Title = "Journal of Medicine - Issue 5", Number = 5, Filename = "Journal_Medicine_05.pdf" },
            new Issue { Id = 6, Title = "Journal of Technology - Issue 1", Number = 1, Filename = "Journal_Technology_01.pdf" },
            new Issue { Id = 7, Title = "Journal of Technology - Issue 2", Number = 2, Filename = "Journal_Technology_02.pdf" },
            new Issue { Id = 8, Title = "Journal of Technology - Issue 3", Number = 3, Filename = "Journal_Technology_03.pdf" },
            new Issue { Id = 9, Title = "Journal of Technology - Issue 4", Number = 4, Filename = "Journal_Technology_04.pdf" },
            new Issue { Id = 10, Title = "Journal of Technology - Issue 5", Number = 5, Filename = "Journal_Technology_05.pdf" },
            new Issue { Id = 11, Title = "Journal of Sports - Issue 1", Number = 1, Filename = "Journal_Sports_01.pdf" },
            new Issue { Id = 12, Title = "Journal of Sports - Issue 2", Number = 2, Filename = "Journal_Sports_02.pdf" },
            new Issue { Id = 13, Title = "Journal of Sports - Issue 3", Number = 3, Filename = "Journal_Sports_03.pdf" },
            new Issue { Id = 14, Title = "Journal of Sports - Issue 4", Number = 4, Filename = "Journal_Sports_04.pdf" },
            new Issue { Id = 15, Title = "Journal of Sports - Issue 5", Number = 5, Filename = "Journal_Sports_05.pdf" },
            new Issue { Id = 16, Title = "Journal of Architecture - Issue 1", Number = 1, Filename = "Journal_Architecture_01.pdf" },
            new Issue { Id = 17, Title = "Journal of Architecture - Issue 2", Number = 2, Filename = "Journal_Architecture_02.pdf" },
            new Issue { Id = 18, Title = "Journal of Architecture - Issue 3", Number = 3, Filename = "Journal_Architecture_03.pdf" },
            new Issue { Id = 19, Title = "Journal of Architecture - Issue 4", Number = 4, Filename = "Journal_Architecture_04.pdf" },
            new Issue { Id = 20, Title = "Journal of Architecture - Issue 5", Number = 5, Filename = "Journal_Architecture_05.pdf" }
        };

        public static IList<Subscription> Subscriptions = new List<Subscription>
        {
            new Subscription { Id = 1, UserId = 1, JournalId = 1 },
            new Subscription { Id = 2, UserId = 1, JournalId = 2 },

            new Subscription { Id = 3, UserId = 2, JournalId = 3 },
            new Subscription { Id = 4, UserId = 2, JournalId = 4 },

            new Subscription { Id = 5, UserId = 3, JournalId = 4 },
            new Subscription { Id = 6, UserId = 3, JournalId = 3 },

            new Subscription { Id = 7, UserId = 4, JournalId = 2 },
            new Subscription { Id = 8, UserId = 4, JournalId = 1 }
        };
    }
}
