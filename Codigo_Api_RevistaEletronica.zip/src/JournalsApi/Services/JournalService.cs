﻿using JournalsApi.Services.Interfaces;
using System.Collections.Generic;
using System.Linq;
using JournalsApi.Domain;

namespace JournalsApi.Services
{
    public class JournalService : IJournalService
    {
        public Journal GetJournalById(int id)
        {
            return FakeData.Journals.FirstOrDefault(j => j.Id == id);
        }

        public IList<Journal> GetJournalsById(IList<int> ids)
        {
            return FakeData.Journals.Where(j => ids.Contains(j.Id)).ToList();
        }

        public Journal GetJournalByIssueId(int issueId)
        {
            return FakeData.Journals.FirstOrDefault(j => j.Issues.Contains(issueId));
        }

        public Issue GetIssueById(int id)
        {
            return FakeData.Issues.FirstOrDefault(e => e.Id == id);
        }

        public IList<Issue> GetIssuesById(IList<int> ids)
        {
            return FakeData.Issues.Where(e => ids.Contains(e.Id)).ToList();
        }
    }
}
