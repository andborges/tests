﻿using JournalsApi.Domain;
using System.Collections.Generic;

namespace JournalsApi.Services.Interfaces
{
    public interface IJournalService
    {
        Journal GetJournalById(int id);

        IList<Journal> GetJournalsById(IList<int> ids);

        Journal GetJournalByIssueId(int issueId);

        Issue GetIssueById(int id);

        IList<Issue> GetIssuesById(IList<int> ids);
    }
}
