﻿using JournalsApi.Domain;

namespace JournalsApi.Services.Interfaces
{
    public interface IUserService
    {
        User GetUserByUsername(string username);
    }
}
