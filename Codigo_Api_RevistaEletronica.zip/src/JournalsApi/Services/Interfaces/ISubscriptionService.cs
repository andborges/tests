﻿using JournalsApi.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JournalsApi.Services.Interfaces
{
    public interface ISubscriptionService
    {
        IList<Subscription> GetSubscriptionsByUserId(int userId);
    }
}
